//
// Created by Jose Santos on 08/09/2022.
//

#ifndef RING_H
#define RING_H
#include "../../results/results.h"

results Run_Ring(int n, int iterations, results results, std::normal_distribution<float> commDelayDist, std::normal_distribution<float> procDelayDist);


#endif
